#! /bin/sh

lolcat -a -s 95 /opt/danix/logo
fish
cd /
